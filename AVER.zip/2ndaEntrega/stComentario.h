#ifndef STCOMENTARIO_H_INCLUDED
#define STCOMENTARIO_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "stLibro.h"
#include "arbolUsuarios.h"

typedef struct {
    int idComentario;  /// �nico, autoincremental
    int idLibro;
    int idUsuario;
    char tituloComentario[100];
    char descripcion[500];
    int puntaje; /// de 0 a 5 "estrellas"
    char fechaComentario[20]; /// o se puede hacer con dia, mes, anio.
    int eliminado; /// 0 si est� activo - 1 si est� eliminado
}stComentario;

typedef struct{
    stComentario dato;
    struct nodoComentario * sig;
}nodoComentario;

/// PROTOTIPADO
stComentario crearComentario(stLibro libro, int idUsuario, nodoComentario* listaComentarios);

nodoComentario* crearNodoComentario(stLibro libro, nodoArbolUsuarios* usuarioLogueado, nodoComentario* listaComentarios);

int generarIdComentario(nodoComentario* listaComentarios);

nodoComentario* agregarAlFinalComentario(nodoComentario* listaComentario, nodoComentario* nuevo);

void mostrarComentariosPorLibro(nodoComentario* listaComentarios, int idLibro);

void mostrarComentario(stComentario comentario);

nodoComentario* cargarComentariosDesdeArchivo(char nombreArchivo[]);

void guardarComentariosEnArchivo(nodoComentario* listaComentarios, char nombreArchivo[]);

void eliminarComentario(nodoComentario* listaComentarios, int idComentario);

void actualizarComentario(nodoComentario* listaComentarios, int idComentario);

int contarComentariosActivos(nodoComentario* listaComentarios);

void filtrarComentariosPorPuntuacion(nodoComentario* listaComentarios, int puntaje);

stComentario* buscarComentarioPorId(nodoComentario* listaComentarios, int idComentario);
/**
void mostrarComentario(stComentario comentario);
nodoComentario * inicListaComentario();
nodoComentario* crearNodoComentario(stLibro libro, nodoArbolUsuarios* usuarioLogueado, nodoComentario* listaComentarios);
stComentario crearComentario(stLibro libro, int idUsuario, nodoComentario* listaC);
int generarIdComentario(nodoComentario * listaComentarios);
nodoComentario * buscaComentarioPorId(nodoComentario * listaComentario, int idComentario);
nodoComentario* buscarUltimoNodoComentario(nodoComentario* listaComentario);
nodoComentario* agregarAlFinalComentario(nodoComentario* listaComentario, nodoComentario* nuevo);
void mostrarComentarios(nodoComentario* lista);
void mostrarComentariosPorLibro(nodoComentario * listaComentarios, int idLibro);
nodoComentario* buscarAeliminar(nodoComentario* listaC, nodoArbolUsuarios* usuarioLogueado, int idComentario);
void editarComentario(stComentario *comentario); **/

#endif // STCOMENTARIO_H_INCLUDED
